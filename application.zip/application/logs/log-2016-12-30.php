<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-12-30 20:02:02 --> Config Class Initialized
INFO - 2016-12-30 20:02:02 --> Hooks Class Initialized
DEBUG - 2016-12-30 20:02:02 --> UTF-8 Support Enabled
INFO - 2016-12-30 20:02:02 --> Utf8 Class Initialized
INFO - 2016-12-30 20:02:02 --> URI Class Initialized
INFO - 2016-12-30 20:02:02 --> Router Class Initialized
INFO - 2016-12-30 20:02:02 --> Output Class Initialized
INFO - 2016-12-30 20:02:02 --> Security Class Initialized
DEBUG - 2016-12-30 20:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 20:02:02 --> Input Class Initialized
INFO - 2016-12-30 20:02:02 --> Language Class Initialized
INFO - 2016-12-30 20:02:02 --> Loader Class Initialized
INFO - 2016-12-30 20:02:02 --> Helper loaded: url_helper
INFO - 2016-12-30 20:02:02 --> Helper loaded: form_helper
INFO - 2016-12-30 20:02:02 --> Helper loaded: date_helper
INFO - 2016-12-30 20:02:02 --> Helper loaded: my_tag_helper
INFO - 2016-12-30 20:02:02 --> Database Driver Class Initialized
DEBUG - 2016-12-30 20:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2016-12-30 20:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-30 20:02:02 --> Form Validation Class Initialized
INFO - 2016-12-30 20:02:02 --> Controller Class Initialized
INFO - 2016-12-30 20:02:02 --> Model Class Initialized
INFO - 2016-12-30 20:02:03 --> Helper loaded: file_helper
INFO - 2016-12-30 20:02:03 --> Upload Class Initialized
INFO - 2016-12-30 20:02:03 --> Language file loaded: language/spanish/upload_lang.php
DEBUG - 2016-12-30 20:02:03 --> No ha seleccionado ningún archivo para subir.
INFO - 2016-12-30 20:02:03 --> File loaded: C:\xampp\htdocs\estadistica\application\views\Estrategia/registro_comprimido.php
INFO - 2016-12-30 20:02:03 --> File loaded: C:\xampp\htdocs\estadistica\application\views\layouts/template1.php
INFO - 2016-12-30 20:02:03 --> Final output sent to browser
DEBUG - 2016-12-30 20:02:03 --> Total execution time: 0.0890
INFO - 2016-12-30 20:02:06 --> Config Class Initialized
INFO - 2016-12-30 20:02:06 --> Hooks Class Initialized
DEBUG - 2016-12-30 20:02:06 --> UTF-8 Support Enabled
INFO - 2016-12-30 20:02:06 --> Utf8 Class Initialized
INFO - 2016-12-30 20:02:06 --> URI Class Initialized
INFO - 2016-12-30 20:02:06 --> Router Class Initialized
INFO - 2016-12-30 20:02:06 --> Output Class Initialized
INFO - 2016-12-30 20:02:06 --> Security Class Initialized
DEBUG - 2016-12-30 20:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-12-30 20:02:06 --> Input Class Initialized
INFO - 2016-12-30 20:02:06 --> Language Class Initialized
INFO - 2016-12-30 20:02:06 --> Loader Class Initialized
INFO - 2016-12-30 20:02:06 --> Helper loaded: url_helper
INFO - 2016-12-30 20:02:06 --> Helper loaded: form_helper
INFO - 2016-12-30 20:02:06 --> Helper loaded: date_helper
INFO - 2016-12-30 20:02:06 --> Helper loaded: my_tag_helper
INFO - 2016-12-30 20:02:06 --> Database Driver Class Initialized
DEBUG - 2016-12-30 20:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2016-12-30 20:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-12-30 20:02:06 --> Form Validation Class Initialized
INFO - 2016-12-30 20:02:06 --> Controller Class Initialized
INFO - 2016-12-30 20:02:06 --> Model Class Initialized
INFO - 2016-12-30 20:02:06 --> Helper loaded: file_helper
INFO - 2016-12-30 20:02:06 --> Upload Class Initialized
INFO - 2016-12-30 20:02:06 --> Language file loaded: language/spanish/upload_lang.php
DEBUG - 2016-12-30 20:02:06 --> No ha seleccionado ningún archivo para subir.
INFO - 2016-12-30 20:02:06 --> File loaded: C:\xampp\htdocs\estadistica\application\views\Estrategia/registro_comprimido.php
INFO - 2016-12-30 20:02:06 --> File loaded: C:\xampp\htdocs\estadistica\application\views\layouts/template1.php
INFO - 2016-12-30 20:02:06 --> Final output sent to browser
DEBUG - 2016-12-30 20:02:06 --> Total execution time: 0.0590
