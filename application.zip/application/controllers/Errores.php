<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Errores extends CI_Controller
{
    	public function __construct()
        {
            
            parent::__construct();
            $this->layout->setLayout('template4');
           $this->load->model("errores_model");
           $this->load->helper("file");
        }


//********************     Cancer           *******************//


public function listar_pap() {
        
          $this->layout->setMensaje("Nominal PAP");
        $datos=$this->errores_model->listar_pap();
        $this->layout->view('listar_errores',compact('datos'));
              
    }


public function listar_ivaa() {
        
          $this->layout->setMensaje("Nominal IVAA ");
        $datos=$this->errores_model->listar_ivaa();
        $this->layout->view('listar_errores',compact('datos'));
        
      }


public function listar_errores_ivaa() {
        
          $this->layout->setMensaje("Lista de Errores IVAA ");
        $datos=$this->errores_model->listar_error_ivaa();
        $this->layout->view('listar_errores',compact('datos'));
        
     }

public function listar_errores_pap() {
        
          $this->layout->setMensaje("Lista de Errores PAP ");
        $datos=$this->errores_model->listar_error_pap();
        $this->layout->view('listar_errores',compact('datos'));
        
     }

public function listar_errores_mama() {
        
          $this->layout->setMensaje("Lista de Errores MAMA ");
        $datos=$this->errores_model->listar_error_mama();
        $this->layout->view('listar_errores',compact('datos'));
        
     }

public function listar_errores_prostata() {
        
          $this->layout->setMensaje("Lista de Errores PROSTATA ");
        $datos=$this->errores_model->listar_error_prostata();
        $this->layout->view('listar_errores',compact('datos'));
        
     }

public function listar_errores_piel() {
        
          $this->layout->setMensaje("Lista de Errores PIEL ");
        $datos=$this->errores_model->listar_error_piel();
        $this->layout->view('listar_errores',compact('datos'));
        
     }


 public function listar_errores_colon() {
        
          $this->layout->setMensaje("Lista de Errores COLON ");
        $datos=$this->errores_model->listar_error_colon();
        $this->layout->view('listar_errores',compact('datos'));
        
     }

public function listar_errores_consejeria() {
        
          $this->layout->setMensaje("Lista de Errores CONSEJERIA ");
        $datos=$this->errores_model->listar_error_consejeria();
        $this->layout->view('listar_errores',compact('datos'));
        
     }
    




//********************     Bucal      *******************//


public function listar_bucal_nino() {
        
          $this->layout->setMensaje("Paquete de Atención Niño");
        $datos=$this->errores_model->listar_bucal_nino();
        $this->layout->view('listar_errores_bucal',compact('datos'));
        
      
    }

public function listar_errores_preventivo() {
        
          $this->layout->setMensaje("Errores Bucal Preventivo");
        $datos=$this->errores_model->listar_errores_preventivo();
        $this->layout->view('listar_errores_odontologia_preventiva',compact('datos'));
    
        
      
    }

public function listar_errores_recuperativo() {
        
          $this->layout->setMensaje("Errores Bucal Recuperativa");
        $datos=$this->errores_model->listar_errores_recuperativo();
        $this->layout->view('listar_errores_odontologia_recuperativa',compact('datos'));
    
        
      
    }

public function listar_bucal_gestante() {
        
          $this->layout->setMensaje("Paquete de Atenciín Gestante");
        $datos=$this->errores_model->listar_bucal_gestante();
        $this->layout->view('listar_bucal_gestante',compact('datos'));
        
      
    }



    //********************     hipertension y diabetes      *******************//


public function listar_diabetes() {
        
          $this->layout->setMensaje("Casos de Diabetes - Tratados No Controlados - Tratados Controlado");
        $datos=$this->errores_model->listar_diabetes();
        $this->layout->view('listar_errores_diabetes',compact('datos'));
        
          }

public function listar_hipertension() {
        
          $this->layout->setMensaje("Casos de hipertension - Tratados No Controlados- Tratados Controlado");
        $datos=$this->errores_model->listar_hipertension();
        $this->layout->view('listar_errores_hipertension',compact('datos'));
    
             
        }

public function valoracion_clinica() {
        
          $this->layout->setMensaje("valoración del índice de masa corporal (IMC), perímetro abdominal, medición de la presión arterial y estilos de vida");
       $datos=$this->errores_model->valoracion_clinica();
       $this->layout->view('listar_errores_valoracion',compact('datos'));
    
             
        }
        
        //********************     Planificacion      *******************//


public function listar_errores_plani_sismed_Controlador() {
        
        if($this->input->post()) 
            {
             
         $mes= $this->input->post('mes');
          $this->layout->setMensaje("Listar errores plani sismed");
          $datos=$this->errores_model->listar_errores_plani_sismed_Modelo($mes);
          $this->layout->view('listar_errores_plani_sismed_Vista',compact('datos'));
            }
          else{
              
              
              $this->layout->view('listar_errores_plani_sismed_inicial_Vista');
              
          }
        
      
    }
    

   
}