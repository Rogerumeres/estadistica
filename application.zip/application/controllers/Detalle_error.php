<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Detalle_error extends CI_Controller
{
    	public function __construct()
        {
            
            parent::__construct();
            $this->layout->setLayout('template5');
           $this->load->model("Erroresdetalle_model");
           
        }



public function edit($id=null)
    {
        
        $datos=$this->Erroresdetalle_model->listar_nominalhiscita($id);
        if(sizeof($datos)==0)
        {
            show_404();
        }
        $this->layout->view("mostrardetalle",compact("id","datos"));



    }
    
public function mostrar_hc($opcion=null,$renaes=null,$mes=null)
    {
        
        $datos=$this->Erroresdetalle_model->listar_sismed_hc($opcion,$renaes,$mes);
        if(sizeof($datos)==0)
        {
            show_404();
        }
        $this->layout->view("mostrardetallehc",compact("datos"));



    }




   
}