                  
<div class="col-sm-12 widget-container-col" id="widget-container-col-2">
   
  

                                            <div class="widget-box widget-color-blue" id="widget-box-2">
                                                
  
                                                
                                                
                                                <div class="widget-header">
                                                  

                                                    
                                                </div>

                                                <div class="widget-body">
                                                    <div class="widget-main no-padding">
                                                        <table class="table table-striped table-bordered table-hover">
                                                            <thead class="thin-border-bottom">

                                                                <tr>
                                                                   
                                                                    <th>
                                                                    Microred
                                                                    </th>

                                                                    
                                                                     <th>                                                                   
                                                                Establecimiento
                                                                    </th>
                                                                    <th>                                                             
                                                                Mes
                                                                    </th>
                                                                    <th>
                                                                    NOMBRES_APELLIDOS
                                                                    </th>
                                                                    <th>
                                                                    NOMBRES_APELLIDOS
                                                                    </th>
                                                                    <th>
                                                                    NOMBRES_APELLIDOS
                                                                    </th>
                                                                    <th>
                                                                    NOMBRES_APELLIDOS
                                                                    </th>
                                                                    <th>
                                                                    NOMBRES_APELLIDOS
                                                                    </th>
                                                                </tr>
                                                            </thead>

                                                            <tbody>

                                                             <?php
                                                           
                                                            foreach ($datos as $row) {
                                  
                                                                     ?> 
                                                                <tr>
                                                                    
                                                                        <td>
                                                                       <center> <?php echo $row->MICRORED ?></center>
                                                                    </td>
                                                                   
                                                                    <td>
                                                                       <center> <?php echo $row->ESTABLECIMIENTO ?></center>
                                                                    </td>
                                                                    <td>
                                                                       <center> <?php echo $row->MES ?></center>
                                                                    </td>
                                                                   
                                                                    <td>
                                                                       <center> <?php echo $row->valor_lab1 ?> |<?php echo $row->id_ciex1 ?>-<?php echo $row->id_tipdiag2 ?>-<?php echo $row->valor_lab2 ?>-<?php echo $row->id_ciex2 ?></center>
                                                                    </td>
                                                                     
                                                                   
                                                                </tr>

                                                               <?php
                                                           }
                                                           ?>

                                                                
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                          <button type="button" class="btn btn-primary btn-lg btn-block" onClick="history.go(-2);">Retornar</button>