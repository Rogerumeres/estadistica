<div class="col-md-12">
        <div class="alert alert-info" role="alert">
        <button class="close" data-dismiss="alert">
                    <i class="ace-icon fa fa-times"></i>
                  </button>
          <h2>Bienvenido <strong><?= $this->session->userdata('usuario'); ?> </strong>al Sistema estadistico de la Red de Servicios de Salud la Convencion</h2>
        </div>
      </div>