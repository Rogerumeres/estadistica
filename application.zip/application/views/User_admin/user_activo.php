<?php
print_r('userid');
?>