<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="page-header">
				<h1>Logout success!</h1>
			</div>
			<p>You are now logged out.</p>
		</div>
	</div><!-- .row -->
</div><!-- .container -->