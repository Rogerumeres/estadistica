<div class="col-md-12">
        <div class="alert alert-info" role="alert">
        <button class="close" data-dismiss="alert">
                    <i class="ace-icon fa fa-times"></i>
                  </button>
          <hp>El cambio de Contraseña se realizo con Éxito</hp>
        </div>
      </div>