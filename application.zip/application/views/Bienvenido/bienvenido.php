<br>
<div class="col-xs-12">
        <div class="alert alert-info" role="alert">
        <button class="close" data-dismiss="alert">
                    <i class="ace-icon fa fa-times"></i>
                  </button>
          <h2>Bienvenido al Sistema de Información de la Red de Servicios de Salud la Convención</h2>
        </div>
      </div>
      
      
      
     
									

								<!-- PAGE CONTENT BEGINS -->
								
									<div class="col-xs-12">
                                        <h3 class="header smaller lighter blue">Reporte Barrido Nacional SPR, APO Y SR 2019</h3>

                                        <a href="<?php echo base_url()?>./uploads/reporte_2019/ReporteCampanaSprApoSr2019.xlsx" class="btn btn-default btn-primary">
											<i class="menu-icon fa fa-eyedropper bigger-200"></i>
											Reporte Avance<br>Barrido 2019
										</a>
                                 
                                        
                                        
                                    </div>
								
								
								
								
									<div class="col-xs-12">
										<h3 class="header smaller lighter blue">Reportes HIS Estrategias Enero-Marzo 2019</h3>

										<p></p>
										
										<a href="<?php echo base_url()?>Mostrar_programa/ver_art" class="btn btn-default btn-primary">
											<i class="ace-icon fa fa-child bigger-200"></i>
											Reporte  <br>Niño
											
										</a>

										<a href="<?php echo base_url()?>Mostrar_programa/ver_mat" class="btn btn-default btn-warning">
											<i class="ace-icon fa fa-female bigger-200"></i>
											Reporte <br>Materno 
											
										</a>

										<a href="<?php echo base_url()?>Mostrar_programa/ver_tras" class="btn btn-default btn-success">
											<i class="ace-icon fa fa-plus-square bigger-200"></i>
											Reporte<br> Transmisibles
										</a>

										<a href="<?php echo base_url()?>Mostrar_programa/ver_no_tras" class="btn btn-default btn-purple ">
											<i class="ace-icon fa fa-eye bigger-200"></i>
											Reporte <br>no Transmisibles
										</a>

										<a href="<?php echo base_url()?>Mostrar_programa/ver_pro_saludf" class="btn btn-default btn-info ">
											<i class="ace-icon fa fa-envelope bigger-200"></i>
											Reporte <br>PROMSA
											
										</a>

										<a href="<?php echo base_url()?>Mostrar_programa/ver_sien" class="btn btn-default btn-pink">
											<i class="ace-icon fa fa-search-minus bigger-200"></i>
											Reporte <br>SIEN
										</a>
										<a href="<?php echo base_url()?>Mostrar_programa/ver_padron" class="btn btn-default btn-danger ">
											<i class="ace-icon fa fa-child bigger-200"></i>
											Padron <br>Nominal
										</a>
										
																			
														</div>
														
														<div class="col-xs-12">
                                        <h3 class="header smaller lighter blue">Errores HIS</h3>

                                        <a href="<?php echo base_url()?>Errores/listar_errores_ivaa" class="btn btn-default btn-inverse">
											<i class="menu-icon fa fa-book bigger-200"></i>
											Errores <br>HIS
										</a>
                                 
                                        

                                        
                                    </div>

									<div class="col-xs-12">
                                        <h3 class="header smaller lighter blue">Reportes consolidado 2016-2018, 2019 actualizado al 17 de Agosto </h3>

                                        <p></p>
                                        
                                        <a href="<?php echo base_url()?>./uploads/reporte_2016/consolidado_2016.zip" class="btn btn-default btn-primary">
                                            <i class="fa fa-file-archive-o bigger-200"></i>
                                            Reporte  <br>Consolidado 2016
                                            
                                        </a>
                                 
                                         <a href="<?php echo base_url()?>./uploads/reporte_2017/Consolidado_2017.zip" class="btn btn-default btn-inverse">
                                            <i class="fa fa-file-archive-o bigger-200"></i>
                                            Reporte  <br>Consolidado 2017
                                            
                                        </a>
                                        <a href="<?php echo base_url()?>./uploads/reporte_2018/reportes 2018.zip" class="btn btn-default btn-pink">
                                            <i class="fa fa-file-archive-o bigger-200"></i>
                                            Reporte  <br>Consolidado 2018
                                            
                                        </a>
                                        
                                         <a href="<?php echo base_url()?>./uploads/reporte_2019/reportes 2019.zip" class="btn btn-default btn-info">
                                            <i class="fa fa-file-archive-o bigger-200"></i>
                                            Reporte  <br>Consolidado 2019
                                            
                                        </a>

                                        
                                    </div>
								
								
								
									
	


								
