                   

            
            
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                 <th>    Año    </th>

                <th>  Mes      </th>
                <th>  MicroRed </th>
                <th>   Establecimiento   </th>    
                <th> Personal de Salud   </th>   
                <th>DNI</th>
                <th>Nombre de Paciente</th>
                <th>Edad</th>
                <th>Tipo edad</th>
                <th>Sexo</th>                                                                      
                <th >Lote HIS</th>
                <th>Página</th>
                <th>Detalles</th>
                </tr>
                </thead>
                <tbody>

                <?php
                                                            
             foreach ($datos as $row) {
                                  
                         ?>

                <tr>
                  <td>
                     <center> <?php echo $row->AÑO ?></center>
                      
                  </td>
                  <td>
                      <center> <?php echo $row->Mes ?></center>
                  </td>
                  <td>
                     <center> <?php echo $row->MicroRed ?></center>
                  </td>
                  <td> 
                    <center> <?php echo $row->Establecimiento ?></center>
                  </td>
                  <td> 
                    <center> <?php echo $row->PERSONAL_SALUD ?></center>
                  </td>

                  <td>
                       <center> <?php echo $row->DNI?></center>
                  </td>
                 
                  <td >
                       <center> <?php echo $row->Paciente ?></center>
                  </td>
                  <td>
                       <center> <?php echo $row->Edad ?></center>
                   </td>
                    <td >
                       <center> <?php echo $row->Tipo_edad ?></center>
                  </td>
                  <td>
                       <center> <?php echo $row->Sexo?></center>

                  </td>

                  <td>
                       <center> <?php echo $row->Lote ?></center>
                  </td>
                 
                  <td>
                       <center> <?php echo $row->Pagina ?></center>
                  </td>
                  <td>
                    <center>
                                                                    <a class='iframe' href="<?php echo base_url()?>Detalle_error/edit/<?php echo $row->ID_CITA?>"><i class="fa fa-eye bigger-200"></i></a></center>
                </td>
               
                </tr>
                 <?php
                                                           }
                    ?>
                
                </tbody>

               
                <tfoot>
                <tr>
                  <th>Año</th>
                  <th>Mes</th>
                  <th>MicroRed</th>
                  <th>Establecimiento</th>
                  <th> Personal de Salud   </th>   
                <th>DNI</th>
                <th>Nombre de Paciente</th>
                <th>Edad</th>
                <th>Tipo edad</th>
                <th>Sexo</th>                                                                      
                <th >Lote HIS</th>
                 
                   <th>Página</th>
                    <th>Detalles</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>



           