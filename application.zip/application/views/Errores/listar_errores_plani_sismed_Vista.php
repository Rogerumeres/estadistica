   
                    
<div class="col-sm-12 widget-container-col" id="widget-container-col-2">
    <?php
$atributos = array( 'id' => 'miformulario','name'=>'form','class'=>'form-horizontal');
//echo form_open(null, $atributos);
echo form_open_multipart('Errores/listar_errores_plani_sismed_Controlador',$atributos);
?>
    
                                                <div class="form-group">
    <select class="custom-select" name="mes" id="mes">
      <option selected="">Seleccione Mes</option>
      <option value="1">Enero</option>
      <option value="2">Febrero</option>
      <option value="3">Marzo</option>
      <option value="4">Abril</option>
      <option value="5">Mayo</option>
      <option value="6">Junio</option>
      <option value="7">Julio</option>
      <option value="8">Agosto</option>
      <option value="9">Setiembre</option>
      <option value="10">Octubre</option>
      <option value="11">Noviembre</option>
      <option value="12">Diciembre</option>
      
    </select>
    <input type="submit" value="Mostrar" title="Mostrar" class="btn btn-primary" id="mostrar"/>
  </div>
  

                                            <div class="widget-box widget-color-blue" id="widget-box-2">
                                                
  
                                                
                                                
                                                <div class="widget-header">
                                                  

                                                    
                                                </div>

                                                <div class="widget-body">
                                                    <div class="widget-main no-padding">
                                                        <table class="table table-striped table-bordered table-hover">
                                                            <thead class="thin-border-bottom">

                                                                <tr>
                                                                   
                                                                    <th>
                                                                    Microred
                                                                    </th>

                                                                    
                                                                     <th>                                                                   
                                                                Establecimiento
                                                                    </th>
                                                                    <th>                                                                   
                                                                Mes
                                                                    </th>
                                                                    
                                                                     <th >DiuSismed</th>
                                                                     <th >DiuHis</th>
                                                                     <th >ConDiu</th>
                                                                     <th >OralCombiandoSismed</th>
                                                                     <th >OralCombinadoHis</th>
                                                                     <th >ConOralCombinado</th>
                                                                     <th >InyectableMensualSisme</th>
                                                                     <th >InyectableMensualHis</th>
                                                                     <th >ConInyectableMensual</th>
                                                                </tr>
                                                            </thead>

                                                            <tbody>

                                                             <?php
                                                           
                                                            foreach ($datos as $row) {
                                  
                                                                     ?> 
                                                                <tr>
                                                                    
                                                                        <td>
                                                                       <center> <?php echo $row->MICRORED ?></center>
                                                                    </td>
                                                                   
                                                                    <td>
                                                                       <center> <?php echo $row->ESTABLECIMIENTO ?></center>
                                                                    </td>
                                                                    <td>
                                                                       <center> <?php echo $row->mes ?></center>
                                                                    </td>
                                                                   
                                                                    <td>
                                                                       <center> <?php echo $row->diuSismed ?></center>
                                                                    </td>
                                                                    <td>
                                                                       <center> <?php echo $row->DiuHis ?></center>
                                                                    </td>
                                                                    <td>
                                                                        <center> <?php if ($row->ConDiu=='Ok') { ?> <a class="iframe" href="<?php echo base_url()?>Detalle_error/mostrar_hc/1/<?php echo $row->RENAES?>/<?php echo $row->mes?>"><i class="fa fa-check bigger-200"></i></a> <?php } else { ?> <a class="iframe" href="<?php echo base_url()?>Detalle_error/mostrar_hc/1/<?php echo $row->RENAES?>/<?php echo $row->mes?>"><i class="fa fa-times bigger-200"></i> </a><?php } ?></center>
                                                                    </td>
                                                                    <td>
                                                                       <center> <?php echo $row->OralCombinadoSismed ?></center>
                                                                    </td>
                                                                    <td>
                                                                       <center> <?php echo $row->OralCombinadoHis ?></center>
                                                                    </td>
                                                                    <td>
                                                                        <center> <?php if ($row->ConOralCombinado=='Ok') { ?> <a href="<?php echo base_url()?>Detalle_error/mostrar_hc/2/<?php echo $row->RENAES?>/<?php echo $row->mes?>"><i class="fa fa-check bigger-200"></i></a> <?php } else { ?> <i class="fa fa-times bigger-200"></i> <?php } ?></center>
                                                                    </td>
                                                                    
                                                                     <td>
                                                                       <center> <?php echo $row->InyectableMensualSismed ?></center>
                                                                    </td>
                                                                    <td>
                                                                       <center> <?php echo $row->InyectableMensualHis ?></center>
                                                                    </td>
                                                                    <td>
                                                                        <center> <?php if ($row->ConInyectableMensual=='Ok') { ?> <a class="iframe" href="<?php echo base_url()?>Detalle_error/mostrar_hc/3/<?php echo $row->RENAES?>/<?php echo $row->mes?>"><i class="fa fa-check bigger-200"></i> </a><?php } else { ?> <i class="fa fa-times bigger-200"></i> <?php } ?></center>
                                                                    </td>
                                                                </tr>

                                                               <?php
                                                           }
                                                           ?>

                                                                
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><!-- /.span -->