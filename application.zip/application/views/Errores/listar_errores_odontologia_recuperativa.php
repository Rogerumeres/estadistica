


<!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                 <th>    Año    </th>
               
                <th>  MicroRed </th>
                <th>   Establecimiento   </th>  
                <th>Personal de Salud</th>
                <th>DNI</th>
                <th>Nombre de Paciente</th>
                <th>Edad</th>
                <th>Tipo edad</th>
                <th>Sexo</th>                                                                  
                <th>Lote HIS</th>
                <th>Página</th>
                <th>Registro</th>
                 <th>  Mes      </th>
                <th>Error Destartraje</th>
                 <th> Error Restauracion Atraumatica</th>
                  <th>Error Consulta Estomatologica </th>
                  <th>Error Exodoncia</th>
                
                <th>Error Restauración Ionomero</th>

                 <th>Error Restauración Resina</th>
     
                
                  <th>Detalles</th>

                </tr>
                </thead>
                <tbody>

                <?php
                                                            
             foreach ($datos as $row) {
                                  
                         ?>

               <tr>
                  <td>
                     <center> <?php echo $row->AÑO ?></center>
                      
                  </td>
                 
                  <td>
                     <center> <?php echo $row->MicroRed ?></center>
                  </td>
                  <td> 
                    <center> <?php echo $row->Establecimiento ?></center>

                  </td>

                    <td> 
                    <center> <?php echo $row->PERSONAL_SALUD ?></center>
                  </td>
                  <td>
                       <center> <?php echo $row->DNI?></center>
                  </td>
                 
                  <td >
                       <center> <?php echo $row->Paciente ?></center>
                  </td>
                  <td>
                       <center> <?php echo $row->Edad ?></center>
                   </td>
                    <td >
                       <center> <?php echo $row->Tipo_edad ?></center>
                  </td>
                  <td>
                       <center> <?php echo $row->Sexo?></center>

                  </td>

                  <td>

                       <center> <?php echo $row->Lote ?></center>
                  </td>
                 
                  <td >
                       <center> <?php echo $row->Pagina ?></center>
                  </td>

                   <td >
                       <center> <?php echo $row->Registro ?></center>
                  </td>
                     <td bgcolor="#48d1cc">
                      <center> <?php echo $row->Mes ?></center>
                  </td>
                  <td bgcolor="#f5fffa">
                       <center> <?php if ($row->ERROR_RASPAJE_DENTAL<>0) { ?> <i class="fa fa-remove bigger-200"></i> <?php } ?></center>
                  </td>

                   <td  bgcolor="#f5fffa">
                        <center> <?php if ($row->ERROR_RESTAURACION_ATRAUMATICA<>0) { ?> <i class="fa fa-remove bigger-200"></i> <?php } ?></center>
                       
                  </td>

                   <td  bgcolor="#f5fffa">
                       <center> <?php if ($row->ERROR_CONSULTA_ESTOMATOLOGICA<>0) { ?> <i class="fa fa-remove bigger-200"></i> <?php } ?></center>
                       
                  </td>


                  <td  bgcolor="#f5fffa">
                       <center> <?php if ($row->ERROR_EXODONCIA<>0) { ?> <i class="fa fa-remove bigger-200"></i> <?php } ?></center>
                      
                  </td>

                   <td  bgcolor="#f5fffa">
                       <center> <?php if ($row->ERROR_RESTAURACION_IONOMERO<>0) { ?> <i class="fa fa-remove bigger-200"></i> <?php } ?></center>
                       
                  </td>
                   <td  bgcolor="#f5fffa">
                       <center> <?php if ($row->ERROR_RESTAURACION_RESINA<>0) { ?> <i class="fa fa-remove bigger-200"></i> <?php } ?></center>
                      
                    </td>
                    


                  <td>
                    <center>
                                                                    <a class='iframe' href="<?php echo base_url()?>Detalle_error/edit/<?php echo $row->ID_CITA?>"><i class="fa fa-eye bigger-200"></i></a></center>
                </td>
               
                </tr>
                 <?php
                                                           }
                    ?>
                
                </tbody>

               
                <tfoot>
                <tr>
                  <th>Año</th>
                  
                  <th>MicroRed</th>
                  <th>Establecimiento</th>
                  <th> Personal de Salud   </th>   
                <th>DNI</th>
                <th>Nombre de Paciente</th>
                <th>Edad</th>
                <th>Tipo edad</th>
                <th>Sexo</th>                                                                      
                <th>Lote HIS</th>
                 
                   <th>Página</th>
                   <th>Registro</th>
                      <th>  Mes      </th>
              <th>Error Destartraje</th>
                 <th> Error Restauracion Atraumatica</th>
                  <th>Error Consulta Estomatologica </th>
                  <th>Error Exodoncia</th>
                
                <th>Error Restauración Ionomero</th>

                 <th>Error Restauración Resina</th>
     
                 <th>Detalles</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>

 