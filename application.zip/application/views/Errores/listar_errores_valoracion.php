                       
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                 <th>    Año    </th>

             
                <th>  MicroRed </th>
                <th>   Establecimiento   </th>    
                <th> Personal de Salud   </th>   
                <th>DNI</th>
                <th>Nombre de Paciente</th>
                <th>Edad</th>
                <th>Tipo edad</th>
                <th>Sexo</th>                                                                      
                <th >Lote HIS</th>
                <th>Página</th>
                 <th>Registro</th>
                
                <th>  Mes      </th>
                <th>  Valoración Clinica sin Riesgo- IMC     </th>
                 <th>  Valoración Clinica Con Riesgo- IMC     </th>
                <th>  Presión Sanguinea      </th>
                 
                  <th>  Tamisaje de Laboratorio    </th>
                  <th>  Perimetro Abdominal     </th>
                 <th>  Error Valoración Clinica     </th>
               
                </tr>
                </thead>
                <tbody>

                <?php
                                                            
             foreach ($datos as $row) {
                                  
                         ?>

                <tr>
                  <td>
                     <center> <?php echo $row->AÑO ?></center>
                      
                  </td>
                 
                  <td>
                     <center> <?php echo $row->MicroRed ?></center>
                  </td>
                  <td> 
                    <center> <?php echo $row->Establecimiento ?></center>
                  </td>
                  <td> 
                    <center> <?php echo $row->PERSONAL_SALUD ?></center>
                  </td>

                  <td>
                       <center> <?php echo $row->DNI?></center>
                  </td>
                 
                  <td >
                       <center> <?php echo $row->Paciente ?></center>
                  </td>
                  <td>
                       <center> <?php echo $row->Edad ?></center>
                   </td>
                    <td >
                       <center> <?php echo $row->Tipo_edad ?></center>
                  </td>
                  <td>
                       <center> <?php echo $row->Sexo?></center>

                  </td>

                  <td>
                       <center> <?php echo $row->Lote ?></center>
                  </td>
                 
                  <td>
                       <center> <?php echo $row->Pagina ?></center>
                  </td>

                  <td>
                       <center> <?php echo $row->Registro ?></center>
                  </td>
                   <td bgcolor="#48d1cc">
                      <center> <?php echo $row->Mes ?></center>
                  </td>

                  <td>
                      
                        <center> <?php if ($row->Valoracion_clinica_sinriesgo<>0) { ?> <a class='iframe' href="<?php echo base_url()?>Detalle_error/edit/<?php echo $row->ID_CITA?>"><i class="fa fa-warning bigger-200"></i></a> <?php } ?></center>
                  </td>
                   <td>
                      
                        <center> <?php if ($row->Valoracion_clinica_conriesgo<>0) { ?> <a class='iframe' href="<?php echo base_url()?>Detalle_error/edit/<?php echo $row->ID_CITA?>"><i class="fa fa-warning bigger-200"></i></a> <?php } ?></center>
                  </td>
                 
                  
                   <td>
                      
                      <center> <?php if ($row->presion_sanguinea<>0) { ?> <a class='iframe' href="<?php echo base_url()?>Detalle_error/edit/<?php echo $row->ID_CITA?>"><i class="fa fa-warning bigger-200"></i></a> <?php } ?></center>
                  </td>

                  <td>
                      
                      <center> <?php if ($row->tamisaje_laboratorio<>0) { ?> <a class='iframe' href="<?php echo base_url()?>Detalle_error/edit/<?php echo $row->ID_CITA?>"><i class="fa fa-warning bigger-200"></i></a> <?php } ?></center>
                  </td>

                   <td>
                      
                      <center> <?php if ($row->Perimetro_abdominal<>0) { ?> <a class='iframe' href="<?php echo base_url()?>Detalle_error/edit/<?php echo $row->ID_CITA?>"><i class="fa fa-warning bigger-200"></i></a> <?php } ?></center>
                  </td>

                  <td bgcolor="#ffeae0">
                      
                      <center> <?php if ($row->ERROR_VALORACION_CLINICA<>0) { ?> <a class='iframe' href="<?php echo base_url()?>Detalle_error/edit/<?php echo $row->ID_CITA?>"><i class="fa fa-times bigger-200"></i></a> <?php } ?></center>
                  </td>



                  
               
                </tr>
                 <?php
                                                           }
                    ?>
                
                </tbody>

               
                <tfoot>
                <tr>
                  <th>Año</th>
                  
                  <th>MicroRed</th>
                  <th>Establecimiento</th>
                  <th> Personal de Salud   </th>   
                <th>DNI</th>
                <th>Nombre de Paciente</th>
                <th>Edad</th>
                <th>Tipo edad</th>
                <th>Sexo</th>                                                                      
                <th >Lote HIS</th>
                 
                   <th>Página</th>
                   <th>Registro</th>
                     <th>Mes</th>

                 <th>  Valoración Clinica sin Riesgo- IMC     </th>
                 <th>  Valoración Clinica Con Riesgo- IMC     </th>
                <th>  Presión Sanguinea      </th>
                 
                  <th>  Tamisaje de Laboratorio    </th>
                  <th>  Perimetro Abdominal     </th>
                 <th>  Error Valoración Clinica     </th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
