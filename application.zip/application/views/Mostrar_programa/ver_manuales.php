

 
  <div class="row">
                                                                    

                                    <div class="col-sm-12">
                                        <div class="tabbable">
                                            <ul class="nav nav-tabs padding-12 tab-color-blue background-blue" id="myTab4">
                                                <li class="active">
                                                    <a data-toggle="tab" href="#reporte">Manuales His Minsa</a>
                                                </li>

                                               

                                                <li>
                                                    <a data-toggle="tab" href="#otros">Otros</a>
                                                </li>
                                            </ul>

                                            <div class="tab-content">
                                                <div id="reporte" class="tab-pane in active">
                                                    
                                                
                               
                                                
 
  
  <p>Descarga los manuales Minsa</p>
  <p class="lead">
    <a class="btn btn-primary btn-lg" href="#" target="_blank" role="button">Ver Aqui</a>
  </p>

                                                
                                                
                                                
                                         
                                                </div>

                                                <div id="norma" class="tab-pane">
                                                    
                                                </div>

                                                <div id="ottros" class="tab-pane">
                                                   
                                                </div>
                                            </div>
                                        </div>
                                    </div><!-- /.col -->
                                </div><!-- /.row -->