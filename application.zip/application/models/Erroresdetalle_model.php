<?php
class Erroresdetalle_model extends CI_Model {

    function __construct()
    {
        parent::__construct();
        
     }


Public function listar_nominalhiscita($id)
    {
        
        $query=$this->db->query("call listar_atenciones($id)");


       
        return $query->row();


/*
        $this->db->select("*");
        $this->db->where("ID_CITA",$id);
        $this->db->from("tbnominalhisminsa");

        $resultado=$this->db->get();
        return $resultado->row();
        */
    }
    
    
    
    Public function listar_sismed_hc($opcion,$renaes,$mes)
    {
        
        $query=$this->db->query("call PAMostrarDetalleInsumosHisHC($opcion,$renaes,2019,$mes)");

        return $query->result();


/*
        $this->db->select("*");
        $this->db->where("ID_CITA",$id);
        $this->db->from("tbnominalhisminsa");

        $resultado=$this->db->get();
        return $resultado->row();
        */
    }

}