<?php
class Errores_model extends CI_Model {

    function __construct()
    {
        parent::__construct();
        
     }

//********************     Cancer           *******************//

public function listar_pap() {
        
        $query=$this->db->query("call Mostrar_cancer(1)");
        return $query->result();
    }

public function listar_ivaa() {
        
        $query=$this->db->query("call Mostrar_cancer(2)");
        return $query->result();
    }

public function listar_error_ivaa() {
        
        $query=$this->db->query("call Mostrar_cancer(3)");
        return $query->result();
    }

public function listar_error_pap() {
        
        $query=$this->db->query("call Mostrar_cancer(4)");
        return $query->result();
    }


public function listar_error_mama() {
        
        $query=$this->db->query("call Mostrar_cancer(5)");
        return $query->result();
    }

public function listar_error_prostata() {
        
        $query=$this->db->query("call Mostrar_cancer(6)");
        return $query->result();
    }

public function listar_error_piel() {
        
        $query=$this->db->query("call Mostrar_cancer(7)");
        return $query->result();
    }

public function listar_error_colon() {
        
        $query=$this->db->query("call Mostrar_cancer(8)");
        return $query->result();
    }

public function listar_error_consejeria() {
        
        $query=$this->db->query("call Mostrar_cancer(9)");
        return $query->result();
    }




//********************     Bucal           *******************//

public function listar_bucal_nino() {
        
        $query=$this->db->query("call Mostrar_bucal(1)");
      
       // ->select("*")
       // ->from("tbnominalhisminsa")
        //->get();
        return $query->result();
    }

public function listar_errores_preventivo() {
        
        $query=$this->db->query("call Mostrar_bucal(2)");
      
       // ->select("*")
       // ->from("tbnominalhisminsa")
        //->get();
        return $query->result();
    }

public function listar_errores_recuperativo() {
        
        $query=$this->db->query("call Mostrar_bucal(3)");
      
       // ->select("*")
       // ->from("tbnominalhisminsa")
        //->get();
        return $query->result();
    }

public function listar_bucal_gestante() {
        
        $query=$this->db->query("call Mostrar_bucal(4)");
      
       // ->select("*")
       // ->from("tbnominalhisminsa")
        //->get();
        return $query->result();
    }


//********************     HIPERTENSION Y DIABETES        *******************//

public function listar_diabetes() {
        
        $query=$this->db->query("call Mostrar_hipertension_diabetes(1)");
      
       // ->select("*")
       // ->from("tbnominalhisminsa")
        //->get();
        return $query->result();
    }

public function listar_hipertension() {
        
        $query=$this->db->query("call Mostrar_hipertension_diabetes(2)");
      
       // ->select("*")
       // ->from("tbnominalhisminsa")
        //->get();
        return $query->result();
    }

public function valoracion_clinica() {
        
        $query=$this->db->query("call Mostrar_hipertension_diabetes(3)");
      
       // ->select("*")
       // ->from("tbnominalhisminsa")
        //->get();
        return $query->result();
    }

public function listar_errores_plani_sismed_Modelo($mes) {
        
        $query=$this->db->query("call PAMostrarHisSismed(2019,$mes)");
      
       // ->select("*")
       // ->from("tbnominalhisminsa")
        //->get();
        return $query->result();
    }




}