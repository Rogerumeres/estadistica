<?php

$lang['required'] 			= "* El campo <strong>%s</strong> es obligatorio.";
$lang['valid_email']		= "* El campo <strong>%s</strong> debe contener una direcci&oacute;n de email v&aacute;lida.";
$lang['validaSelect']		= "* Debe indicar alguna opción en el campo <strong>%s</strong>.";
$lang['min_length[6]']		= "* contraseña debe tener minimo 6 caracteres.";


/* End of file form_validation_lang.php */
/* Location: ./system/language/spanish/form_validation_lang.php */
